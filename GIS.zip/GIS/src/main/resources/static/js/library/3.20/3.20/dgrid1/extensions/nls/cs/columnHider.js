//>>built
define("dgrid1/extensions/nls/cs/columnHider",{popupLabel:"Zobrazit nebo skr\u00fdt sloupce"});