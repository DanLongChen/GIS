//>>built
define("dgrid1/extensions/nls/ja/columnHider",{popupLabel:"\u5217\u306e\u8868\u793a/\u975e\u8868\u793a"});