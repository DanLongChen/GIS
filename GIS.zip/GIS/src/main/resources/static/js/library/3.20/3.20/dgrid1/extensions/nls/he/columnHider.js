//>>built
define("dgrid1/extensions/nls/he/columnHider",{popupLabel:"\u05d4\u05e6\u05d2 \u05d0\u05d5 \u05d4\u05e1\u05ea\u05e8 \u05e2\u05de\u05d5\u05d3\u05d5\u05ea"});