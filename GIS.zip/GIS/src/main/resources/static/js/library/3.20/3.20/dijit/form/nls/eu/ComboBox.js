//>>built
define("dijit/form/nls/eu/ComboBox",{previousMessage:"Aurreko aukerak",nextMessage:"Aukera gehiago"});