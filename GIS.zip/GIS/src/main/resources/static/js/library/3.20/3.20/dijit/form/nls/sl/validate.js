//>>built
define("dijit/form/nls/sl/validate",{invalidMessage:"Vnesena vrednost ni veljavna.",missingMessage:"Ta vrednost je zahtevana.",rangeMessage:"Ta vrednost je izven obmo\u010dja."});