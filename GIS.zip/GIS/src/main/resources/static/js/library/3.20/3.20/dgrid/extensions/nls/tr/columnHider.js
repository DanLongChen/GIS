//>>built
define("dgrid/extensions/nls/tr/columnHider",{popupLabel:"S\u00fctunlar\u0131 g\u00f6ster ya da gizle"});